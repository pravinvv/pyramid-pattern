import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  title = "pattern";
  count = 0;
  arrayStore = [];
  constructor() {
    this.incCount();
  }

  incCount() {
    this.arrayStore[this.count++] = this.arrayStore.map(arr => arr);
    console.log(this.arrayStore);
  }
}
